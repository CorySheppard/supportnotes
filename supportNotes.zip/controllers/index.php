<?php

view('index.view.php', [
    'pageTitle' => 'Home',
]);