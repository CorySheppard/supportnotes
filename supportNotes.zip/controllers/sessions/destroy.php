<?php

// Log the user out

logout();

// Redirect the user to the homepage

header("Location: /");
die();