<?php

view('notes/create.view.php', [
    'pageTitle' => 'Create a Note',
    'errors' => [],
]);