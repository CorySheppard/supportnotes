<?php

return [
    "database" => [
        "mysql" => "localhost",
        "port" => 3306,
        "dbname" => "supportnotes",
        "charset" => "utf8mb4",
    ]
];
